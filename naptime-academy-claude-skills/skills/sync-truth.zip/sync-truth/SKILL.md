---
name: sync-truth
description: Keep the facts about the user's business consistent everywhere. Builds and maintains one Brand Truth file (offers, prices, links, bios, stats, taglines, key dates) as the single source of truth, then finds and updates the places those facts live, like Notion pages, Google Docs, or a media kit, and hands back a checklist for the spots Claude can't reach. Use when the user says "sync my truth", "update my brand facts", "my price changed", "I changed my link", "update my bio everywhere", "make everything consistent", or after they change an offer, price, link, or bio.
---

# Sync Truth

One file is the boss, and everything else copies it. When a price, link, offer, or bio changes, change it once in the Brand Truth file. This skill carries it everywhere else.

**Brand Truth vs. Brand Homebase:** your Homebase is how you *sound*. Your Brand Truth is what's *true right now*: offers, prices, links, and numbers. Keep them separate, because voice changes rarely and facts change all the time.

## Step 1: find (or build) the Brand Truth file

Look for a document called "My Brand Truth" in this project or chat, or a file named `brand-truth.md`.

Not there? Build it with them in two short rounds, not twenty questions:

- **Round 1:** their business name and handle, what they sell (each offer's name, price, link, and whether it's live, coming soon, or retired), and their main links (link in bio, booking, shop, freebie).
- **Round 2:** their bios (Instagram, short, and long), the taglines or phrases they always use, the numbers they share publicly (followers, email list, clients served) with today's date, and anything they never claim.

Then hand it back in this structure, and tell them to save it in their Project (or as `brand-truth.md` in their business folder):

```
# My Brand Truth
Last updated: [date]

## Business
- Name / handle:
- What I do (one line):

## Offers
| Offer | Price | Link | Status |
|---|---|---|---|

## Links
- Link in bio:
- Booking:
- Shop / store:
- Freebie:

## Bios
- Instagram (150 characters max):
- Short bio:
- Long bio:

## Numbers (with dates)
| Stat | Exact number | Date checked | Say it publicly as |
|---|---|---|---|

## Taglines and phrases

## Key dates (launches, sales, events)

## Never say or claim
```

**The "say it publicly as" column matters.** Exact numbers go stale fast. A rounded version like "10K+" never has to be fixed in an old post.

## Step 2: when something changes

1. Update the Brand Truth file first. Show them exactly what changed (old, then new) and let them confirm.
2. Change the "Last updated" date.

## Step 3: carry it everywhere

1. **Find every spot it lives.** Search everything you can reach: connected Notion or Google Drive (search for the old price, old link, or old name), and files in their business folder if you're working on their computer.
2. **Make surgical edits.** Change only the outdated fact. Don't rewrite the copy around it.
3. **Ask before touching anything customers see live**, like a sales page, a checkout, or an email that's already sending. Never change a live price without a clear yes.
4. **Build a checklist for the places you can't reach.** Always include the likely spots: Instagram bio, link-in-bio page, pinned posts and highlights, sales and checkout pages, welcome emails and automations, media kit, Canva templates, plus any other platform they mention.

## Step 4: report back

Keep it to one short report:

- **Updated:** a table of every place you changed (where, old, new).
- **Still to update by hand:** the checklist, as checkboxes.
- **Needs your call:** anything live you didn't touch, and any number you couldn't verify.

## Rules

- Never invent a number, price, or result. If you can't verify something, say so and use the rounded public wording.
- Changes flow one direction only, from Brand Truth to everywhere else. If you find a place that disagrees, flag it. Don't copy it back into the file.
- Optional check: if their store platform or Apify is connected, you can compare live prices or follower counts against the file and flag any difference. With Apify, tell them the rough cost before running anything.
