---
name: caption
description: Write one social media caption in the user's own voice, ready to paste, with nothing before or after it. Use when the user says "caption this", "write me a caption", "caption for my reel", "caption for my carousel", types /caption, or shares a post, reel script, or idea and wants the caption for Instagram, TikTok, Facebook, or LinkedIn.
---

# Caption

Write ONE caption for the user's post, in their voice, ready to paste. The whole point is speed: they ask, they paste, they post.

## Step 1: learn their voice (fast)

Use the first of these you can find:

1. **Their Brand Homebase.** This is a document called "My Brand Homebase" (or a file named `brand-homebase.md`) in this project, folder, or chat. Follow its voice, the words they love, the words they never use, and their rules.
2. **Anything else about their voice.** A style guide, a brand doc, or past captions they've shared in this project or chat.
3. **Nothing yet?** Ask these three questions in ONE message, then write the caption as soon as they answer:
   - Who is this post for? (The one person you picture reading it.)
   - Paste 2 or 3 captions you've written that sound like you. (No captions yet? Describe how you talk in a few words.)
   - Is there anything you never want in a caption? (Certain words, emoji, hashtags, all caps.)

   After that first caption, add one short line: "Want me to remember your voice? Save your answers in your Project, or build your Brand Homebase." Say this only during first-time setup, never again.

## Step 2: write it

### The contract (this is the whole skill)

- Output the caption and nothing else. No intro line, no "here's your caption," no options, no question at the end, no offer to tweak it.
- If they ask for a change, reply with only the new caption.
- If they ask for options, give exactly that many, numbered, and nothing else.
- If you're working on their computer (like in Claude Code), also copy the caption to their clipboard quietly. Never mention it, and never let it slow down or change the caption. If there's no clipboard, skip it.

  ```
  export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
  cat > /tmp/.caption.txt <<'CAP'
  <the exact caption>
  CAP
  pbcopy < /tmp/.caption.txt 2>/dev/null || wl-copy < /tmp/.caption.txt 2>/dev/null || xclip -selection clipboard < /tmp/.caption.txt 2>/dev/null || clip < /tmp/.caption.txt 2>/dev/null || true
  ```

### What makes a caption work

- **The first line is the hook.** It shows in the feed before "more," so make it specific and a little surprising. Skip "Have you ever...?" openers.
- **Add what the post doesn't say.** Share a quick story, the why behind it, or one detail they'd only get here. Don't re-list the slides or repeat the video.
- **Short paragraphs, plain words, lots of white space.**
- **End with one clear ask that fits the post.** Comment a keyword to get something ("comment GUIDE and I'll send it to you"), save it for later, send it to a friend, or follow for more. For a keyword ask, build the curiosity first and put the keyword last.
- **Use hashtags only if their voice already does.** A few specific ones, never a wall.
- **Match their habits exactly:** capitalization, emoji, line breaks, sign-offs.

### Make it sound like a person

- No em dashes. They're one of the clearest signs a caption was written by AI. Use periods and commas instead, unless their own captions use em dashes.
- No hype or filler, like "game-changer," "unlock," "elevate," "let's dive in," or "in today's world."
- Lead with hope. Never make the reader feel behind or ashamed.
- Every line moves forward. Don't say the same thing twice.
- Never invent numbers, results, or testimonials. If they didn't give you a number, leave it out.
