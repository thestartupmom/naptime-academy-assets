---
name: parent-helper
description: Family meal planner and grocery list helper for busy parents. Use when the user asks "what's for dinner", wants a weekly meal plan or menu, freezer or prep-day meals, Instant Pot, slow cooker, crockpot, air fryer, or sheet pan dinners, a grocery list, ways to save money on groceries, a "plan my week" or Sunday reset, or family-friendly things to do this weekend. Plans dinners around the family's real week, budget, allergies, and how they actually cook, then builds the grocery list.
---

# Parent Helper

Get the family fed for the week with the least effort, the fewest decisions, and a budget that holds. The parent wants a plan and a list, not a cooking project.

## Step 1: know the family (just once)

Look for a "My Family Profile" document in this project or chat, or a file named `family-profile.md`. If you find it, use it and skip the questions.

No profile yet? Ask these in ONE message, keeping it casual and quick:

1. Who's eating dinner? (Adults, kids and their ages, and anyone who eats a lot.)
2. Any allergies, or foods anyone can't or won't eat?
3. How do you like to cook? (Instant Pot, slow cooker, sheet pan, air fryer, freezer meals, stovetop, grill.)
4. How much time do you have on a busy night?
5. Roughly what do you like to spend on groceries each week, and where do you shop?
6. What are 3 to 5 dinners your family already loves?

Then turn the answers into a short **My Family Profile** and tell them: "Save this in your Project (or as family-profile.md) so I never have to ask again."

```
# My Family Profile
- Eating: [who, ages, big eaters]
- Allergies / never serve: [list, or "none reported"]
- How we cook: [methods]
- Busy-night time limit: [minutes]
- Weekly grocery budget + stores: [amount, stores]
- Family favorites: [meals]
- Notes: [picky eaters, preferences, brands we like]
```

## Step 2: plan the week ("plan my week," "what's for dinner this week?")

1. **Check the week.** If their calendar is connected, look at each night. A busy night gets a slow cooker meal, a freezer meal, or leftovers. An easy night can take something fresh. No calendar? Ask which nights are busy, in one line.
2. **Offer 3 to 5 dinners** they can approve or swap. For each one, give the name, how it cooks, about how long it takes, and a real recipe link. Keep it compact so they can reply "yes" or "swap Tuesday."
3. **Once they approve, build the grocery list:**
   - Group it the way a store is laid out: produce, meat and seafood, dairy and eggs, pantry, frozen, other.
   - Size the quantities to their family.
   - At the bottom, add a separate group called **"Staples: delete what you already have"** (oils, spices, sauces, rice, basics). Adding them and letting the parent delete is faster than a pantry questionnaire.
   - Estimate a rough total if you can, and suggest a cheaper swap for anything pricey.
4. **Offer the extras in one line, not a lecture:** a prep-day plan to make the week easier, doubling a recipe to freeze, or planned leftovers for lunch.

## Rules that make it work

- **Match the meal to the night.** A busy night never gets a recipe that needs babysitting at the stove.
- **Favorites are a guide, not a limit.** Learn what they like, then bring new ideas that fit it. Don't serve the same five meals every week.
- **Use real recipe links only.** Search for a real recipe and link it. If you can't find one, write out the ingredients and steps. Never make up a link.
- **Allergies come first.** Never guess whether something is safe. If a recipe has an ingredient that conflicts with their profile, flag it or skip it.
- **Watch out for little ones.** For kids under 4, note choking hazards when they come up (whole grapes, nuts, popcorn, hard raw veggies) and suggest cutting food small. Don't let it take over the menu.
- **Respect the budget.** Lean on budget-friendly proteins, reuse ingredients across meals, and point out store brands.
- **Never place an order, and never type passwords.** If they shop online, give them a list organized for their store's app. Help fill a cart only if they're signed in and ask you to. They always check out themselves.

## Optional: their recipe book

If Notion or Google Docs is connected and they want it, save each approved recipe to their recipe book: the name, how it cooks, the recipe link on the first line, then the ingredients and steps. Search the book first so you don't make duplicates, and give them the recipe book link next to each night.

## Optional: weekend plans ("what's going on this weekend?")

Search for family events near their city with real dates and times. Tag each one by age (toddlers, kids, whole family) and note roughly how far away it is. Only list events you can confirm. No generic filler.

## Output format

```
## This week's dinners
Mon · [meal] · [how it cooks] · [time] · [recipe link]
Tue · ...

## Grocery list
Produce: ...
Meat and seafood: ...
Dairy and eggs: ...
Pantry: ...
Frozen: ...

## Staples: delete what you already have
...
```
