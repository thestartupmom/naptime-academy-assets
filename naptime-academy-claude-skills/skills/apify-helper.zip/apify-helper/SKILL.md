---
name: apify-helper
description: Beginner-friendly helper for using Apify through Claude to pull real, public data from Instagram, TikTok, YouTube, Facebook, Google Maps, and websites. Picks the right Apify scraper for the job, tells the user the rough cost before running anything, caps the spend, runs a small test first, and turns the results into something useful like a content idea list, a competitor breakdown, a lead list, or a spreadsheet. Use when the user mentions Apify, scraping, pulling posts or stats from a profile, checking competitors, studying top posts, mining comments for content ideas, finding local businesses or brand contacts, getting video transcripts, or turning a website into notes. Needs the Apify connector.
---

# Apify Helper

Claude can't open Instagram links or see anyone's numbers on its own. Apify can. This skill makes Apify easy and safe: the user says what they want in plain words, and you pick the right scraper, check the cost, run it small, and hand back something they can use today.

## Step 0: make sure Apify is connected

Look for Apify tools in this chat, like `search-actors`, `fetch-actor-details`, `call-actor`, and `get-dataset-items`.

If they're missing, don't guess and don't fake results. Give them the setup and stop:

1. Make a free account at apify.com (no credit card needed).
2. In Claude, go to **Customize**, then **Connectors**. Tap **+**, then **Browse connectors**, search for **Apify**, and connect it. If it's not listed, tap **+**, then **Add custom connector**, and paste `https://mcp.apify.com`.
3. Sign in to Apify in the window that opens, and allow access.
4. Come back and ask again.

In Claude Code, the command is `claude mcp add --transport http apify https://mcp.apify.com`. Then type `/mcp`, pick Apify, and sign in.

## The golden rules (every single run)

1. **Cost first, always.** Once Apify is connected, runs can spend real money, so never start one without a yes. Before any run, use `fetch-actor-details` to check the scraper's current pricing. Tell them the rough cost in one line ("20 posts should cost about 5 cents of your Apify credit") and wait for a yes. Never skip this, even for tiny runs.
2. **Set limits two ways.** Always set the scraper's own result limit in the input (like `resultsLimit`, `maxItems`, `maxCrawlPages`, or the per-search maximum). Some scrapers default to enormous runs (a Pinterest search can default to 50,000 results, and the website crawler to millions of pages). Then also pass `callOptions.maxTotalChargeUsd` set to the amount they approved, so the run can't bill more than that.
3. **Start small.** The first run is 5 to 20 results. Only go bigger after they've seen the results and said yes to the new cost.
4. **Skip paid add-ons unless they ask.** Extras like "business leads" or "email verification" on the Google Maps and contact scrapers cost far more per result, especially on the free plan. Leave them off by default and mention them only if they'd really help.
5. **Public info only.** Only public profiles, posts, pages, groups, and business listings. Never try to reach private accounts or personal info that isn't publicly posted. Public info can still be protected by privacy laws, so collect only what they need for a real reason.
6. **Study, don't copy.** Results are for learning what works. Never hand back someone else's caption or script as the user's content. Pull out the pattern, then write something new in the user's voice.
7. **No spam.** Business contact details are for personal, one-to-one outreach someone would be glad to get, not a mass email list.
8. **Pull once, reuse it.** Don't re-run a scraper to re-read data you already have. If results look cut off, get the full set with `get-dataset-items` (use `limit` and `offset` to page through).
9. **Check inputs before you run.** Inputs change, so read the input schema in `fetch-actor-details` when you're unsure of a field. If a run fails, say what failed in one line and suggest a fix. Never fill gaps with made-up data.

**The free Apify plan** includes $5 of usage every month with no card. When it's used up, runs pause until next month, so there are no surprise bills. Unused credit doesn't roll over.

## The menu (what to reach for)

| They want to... | Scraper | They give you | You get |
|---|---|---|---|
| Check an account (followers, bio, recent posts) | `apify/instagram-profile-scraper` | usernames | followers, bio, post count, latest posts |
| See an account's posts and captions | `apify/instagram-post-scraper` | usernames or post links | captions, likes, comments, hashtags, dates |
| Study reels, with what was said | `apify/instagram-reel-scraper` | usernames or reel links | views, likes, captions, length, and transcripts if asked (transcripts cost the most) |
| Mine comments for content ideas | `apify/instagram-comment-scraper` | post or reel links | comment text and time (the free plan returns only the top 15 comments per post) |
| Study TikTok | `clockworks/tiktok-scraper` | usernames, hashtags, searches, or video links | video stats, captions, author, music |
| Get YouTube video text | `starvibe/youtube-video-transcript` | video links | the transcript plus video details |
| Study Facebook Page posts | `apify/facebook-posts-scraper` | public Page links | posts and their engagement |
| Study a public Facebook group | `apify/facebook-groups-scraper` | public group links | posts and comments |
| Turn a website into notes | `apify/website-content-crawler` | a website link (always set a page limit) | clean page text Claude can read |
| Find local businesses or brands | `compass/crawler-google-places` | a search plus a city ("kids boutiques in Nashville") | names, addresses, websites, phones, ratings |
| Find a business's public contact info | `vdrmota/contact-info-scraper` | website links | public emails, phones, social links |
| Research a question on the web | `apify/rag-web-browser` | a question or a link | clean text from the top results |

Not on the list? Use `search-actors` with plain words ("pinterest scraper"). Pick one with lots of users and good ratings, check its input and price with `fetch-actor-details`, set a result limit, and follow the golden rules.

## Recipes (the ones that pay off fast)

### "What's working in my niche?"
1. Ask for 3 to 5 accounts in their niche (or suggest a few if they're not sure).
2. Pull each account's recent reels or posts (10 per account, from the last 3 months).
3. Rank each post against that account's own usual numbers. Use the median, not the average, so one viral post doesn't hide the rest.
4. Hand back the top 5 posts, their exact hook lines, the formats that keep winning, and 5 ideas for the user's niche with the hook written out.

### "Give me content ideas from comments"
1. Ask for 2 or 3 posts in their niche that got lots of comments.
2. Pull the comments.
3. Group them into the questions people keep asking, the struggles they mention, and the words they use.
4. Hand back the top 10 questions, each turned into a post idea with a hook in the audience's own words.

### "Check my own numbers"
1. Pull their own profile and recent posts.
2. Hand back a simple scorecard: their best 3 posts and why, their weakest 3, and what the best ones have in common.

### "Build me a list of local businesses to pitch"
1. Ask what kind of business and which city.
2. Run the Google Maps scraper with 20 results to start, add-ons off.
3. If they want, run the contact info scraper on those websites.
4. Hand back a clean table: name, website, public email or contact page, Instagram, and a one-line idea for why each is a good fit. Remind them to personalize every message.

### "Turn this video or website into notes"
1. Pull the transcript (YouTube) or the page text (website crawler, with a page limit).
2. Hand back what they asked for: a summary, key takeaways, a blog outline, or 5 post ideas in their voice.

## Hand it back clean

- Lead with the answer, not the raw data.
- Put the details in a tidy table.
- Offer one next step: "Want this as a spreadsheet?" (make a CSV or Excel file), "Want me to write the first post?", or "Want to run it bigger?" (with the new cost).
- Apify deletes unsaved results after 7 days, so offer a spreadsheet of anything worth keeping.
- If they have a Brand Homebase ("My Brand Homebase" or `brand-homebase.md`), write any ideas or hooks in their voice.
